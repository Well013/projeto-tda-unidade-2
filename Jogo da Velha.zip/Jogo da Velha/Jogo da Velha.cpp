#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/*				Jogo da Velha - 3x3

		Projeto da Segunda Unidade da cadeira de T�cnicas e Desenvolvimento de Algoritmos
		
		Turma: Ci�ncia da Computa��o - P2E (Quarta-feira)
		
		Equipe:
		
		- Wellington
		- L�gia
		- Clara
		- �lvaro
		- Gabrielle
*/

// Vari�veis Globais
char** jogo;
char jogador1[50], jogador2[50];

// Fun��o para solicitar o nome dos jogadores
void nomeJogador() {
    printf("Digite o nome do Jogador 1 (X): ");
    scanf("%49[^\n]", jogador1);

    printf("Digite o nome do Jogador 2 (0): ");
    scanf(" %49[^\n]", jogador2);
}

// Procedimento para inicializar todas as posi��es da matriz
void inicializarMatriz() {
    // Aloca dinamicamente a matriz
    jogo = (char**)malloc(3 * sizeof(char*));
    for (int i = 0; i < 3; i++) {
        jogo[i] = (char*)malloc(3 * sizeof(char));
    }

    // Loop para percorrer as linhas
    for (int linha = 0; linha < 3; linha++) {
        // Loop para percorrer as colunas
        for (int coluna = 0; coluna < 3; coluna++)
            // Atribui ' ' a cada posi��o da matriz
            jogo[linha][coluna] = ' ';	
    }
}

// Procedimento para imprimir o jogo na tela
void imprimir() {
    // Indica onde se encontra as Colunas e as posi��es delas
    printf("\n\t   Coluna\n\n\t 0   1   2\n\n");

    // Loop para percorrer as linhas
    for (int linha = 0; linha < 3; linha++) {
        // Loop para percorrer as colunas
        for (int coluna = 0; coluna < 3; coluna++) {
            // Formata��o da sa�da
            if (coluna == 0)
                printf("\t");

            // Impress�o do caractere na posi��o (linha, coluna)
            printf(" %c ", jogo[linha][coluna]);

            // Formata��o da sa�da
            if (coluna < 2)
                printf("|");

            // Formata��o da sa�da
            if (coluna == 2)
                printf("\t%d", linha);
        }
        // Quebra de linha
        printf("\n");

        // Formata��o da sa�da
        if (linha < 2)
            printf("\t------------\n");
    }

    // Indica onde se encontra as Linhas e as posi��es delas
    printf("\n\t\t      Linha\n");
}

// Fun��o para verificar vit�ria por linha
int ganhouPorLinha(int linha, char l) {
    // Verifica se todos os elementos na linha s�o iguais a l
    if (jogo[linha][0] == l && jogo[linha][1] == l && jogo[linha][2] == l)
        return 1;
    else 
        return 0;
}

// Fun��o para verificar vit�ria por linhas
int ganhouPorLinhas(char l) {
    // Vari�vel para contar o n�mero de vit�rias por linha
    int ganhou = 0;

    // Loop para verificar cada linha
    for (int linha = 0; linha < 3; linha++)
        ganhou += ganhouPorLinha(linha, l);

    return ganhou;
}

// Fun��o para verificar vit�ria por coluna
int ganhouPorColuna(int coluna, char c) {
    // Verifica se todos os elementos na coluna s�o iguais a c
    if (jogo[0][coluna] == c && jogo[1][coluna] == c && jogo[2][coluna] == c)
        return 1;
    else 
        return 0;
}

// Fun��o para verificar vit�ria por colunas
int ganhouPorColunas(char c) {
    // Vari�vel para contar o n�mero de vit�rias por coluna
    int ganhou = 0;

    // Loop para verificar cada coluna
    for (int coluna = 0; coluna < 3; coluna++)
        ganhou += ganhouPorColuna(coluna, c);

    return ganhou;
}

// Fun��o para verificar vit�ria por diagonal principal
int ganhouPorDiagonalPrin(char p) {
    // Verifica se todos os elementos na diagonal principal s�o iguais a p
    if (jogo[0][0] == p && jogo[1][1] == p && jogo[2][2] == p)
        return 1;
    else
        return 0;
}

// Fun��o para verificar vit�ria por diagonal secund�ria
int ganhouPorDiagonalSec(char s) {
    // Verifica se todos os elementos na diagonal secund�ria s�o iguais a s
    if (jogo[0][2] == s && jogo[1][1] == s && jogo[2][0] == s)
        return 1;
    else
        return 0;
}

// Fun��o para validar coordenada
int ehValida(int linha, int coluna) {
    // Verifica se a coordenada est� dentro dos limites e se a posi��o est� vazia
    if (linha >= 0 && linha < 3 && coluna >= 0 && coluna < 3 && jogo[linha][coluna] == ' ')
        return 1;
    else
        return 0;
}

// Procedimento para ler as coordenadas
void lerCoordenadas(char jogador) {
    // Vari�veis para armazenar as coordenadas
    int lerLinha, lerColuna;

    // Entrada do usu�rio para a linha
    printf("\n\n%s, digite a linha (0, 1 ou 2): ", (jogador == 'X') ? jogador1 : jogador2);
    scanf("%d", &lerLinha);

    // Entrada do usu�rio para a coluna
    printf("%s, digite a coluna (0, 1 ou 2): ", (jogador == 'X') ? jogador1 : jogador2);
    scanf("%d", &lerColuna);

    // Loop para garantir coordenadas v�lidas
    while (ehValida(lerLinha, lerColuna) == 0) {
        // Mensagem de erro
        printf("\n\nCoordenadas Inv�lidas, digite outra Linha e Coluna.");

        // Nova entrada do usu�rio para a linha
        printf("\n\n%s, digite a linha (0, 1 ou 2): ", (jogador == 'X') ? jogador1 : jogador2);
        scanf("%d", &lerLinha);

        // Nova entrada do usu�rio para a coluna
        printf("%s, digite a coluna (0, 1 ou 2): ", (jogador == 'X') ? jogador1 : jogador2);
        scanf("%d", &lerColuna);	
    }

    // Atribui o caractere do jogador � posi��o especificada
    jogo[lerLinha][lerColuna] = jogador;
}

// Fun��o para contar a quantidade de posi��es vazias
int quantVazias() {
    // Vari�vel para armazenar a quantidade de posi��es vazias
    int quantidade = 0;

    // Loop para percorrer a matriz
    for (int linha = 0; linha < 3; linha++) {
        for (int coluna = 0; coluna < 3; coluna++)
            // Conta as posi��es vazias
            if (jogo[linha][coluna] == ' ')
                quantidade++;
    }	
    return quantidade;
}

// Fun��o para liberar a mem�ria alocada para a matriz
void liberarMatriz() {
    for (int i = 0; i < 3; i++) {
        free(jogo[i]);
    }
    free(jogo);
}

// Procedimento principal para jogar
void jogar() {
    // Vari�veis para controlar o jogador e verificar vit�rias
    int jogador = 1, vitoriaX = 0, vitoriaO = 0;

    // Loop principal do jogo
    do {
        // Chamada da fun��o para imprimir o jogo
        imprimir();

        // Verifica o jogador atual e realiza as a��es correspondentes
        if (jogador == 1) {
            // Chamada da fun��o para ler as coordenadas do jogador 1
            lerCoordenadas('X');
            
            // Atualiza jogador e verifica vit�rias
            jogador++;
            vitoriaX += ganhouPorLinhas('X');
            vitoriaX += ganhouPorColunas('X');
            vitoriaX += ganhouPorDiagonalPrin('X');
            vitoriaX += ganhouPorDiagonalSec('X');
        }
        else {
            // Chamada da fun��o para ler as coordenadas do jogador 2
            lerCoordenadas('O');
            
            // Atualiza jogador e verifica vit�rias
            jogador = 1;
            vitoriaO += ganhouPorLinhas('O');
            vitoriaO += ganhouPorColunas('O');
            vitoriaO += ganhouPorDiagonalPrin('O');
            vitoriaO += ganhouPorDiagonalSec('O');
        }
    } while (vitoriaX == 0 && vitoriaO == 0 && quantVazias() > 0);

    // Mensagem de resultado do jogo
    if (vitoriaX == 1) {
        printf("\nParab�ns %s. Voc� venceu!!\n", jogador1);
    }
    else if (vitoriaO == 1) {
        printf("\nParab�ns %s. Voc� venceu!!\n", jogador2);
    }
    else {
        printf("\nQue pena, ningu�m ganhou!!\n");
    }

    // Libera a mem�ria alocada para a matriz no final do jogo
    liberarMatriz();

    // Mensagem perguntando se o jogador quer iniciar um novo jogo
    printf("\nDeseja Iniciar um Novo Jogo??\n");

    // Chama a fun��o para inicializar a matriz para um novo jogo
    inicializarMatriz();
}

// Fun��o principal
int main () {
    setlocale(0, "Portuguese");

    // Chama a fun��o para solicitar o nome dos jogadores
    nomeJogador();

    // Chama a fun��o para inicializar a matriz
    inicializarMatriz();

    // Vari�vel de op��o para jogar novamente
    char opcao = 's';

    // Loop principal do programa
    do {
        // Chama a fun��o para jogar
        jogar();

        // Mensagem para jogar novamente
        printf("\n\nDigite 's' (min�sculo) para Jogar Novamente: ");
        scanf(" %c", &opcao);
    } while (opcao == 's');

    return 0;
}
